var E=(T=>(T.STUDENT="STUDENT",T.TEACHER="TEACHER",T))(E||{});const r={STUDENT:"学生",TEACHER:"老师"};export{r as R,E as a};
