var a=(C=>(C[C.ASC=0]="ASC",C[C.DESC=1]="DESC",C))(a||{});export{a as S};
