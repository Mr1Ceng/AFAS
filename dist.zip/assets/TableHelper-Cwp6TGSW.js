const i=e=>Object.entries(e).map(([t,n])=>({title:n,dataIndex:t,ellipsis:!0,align:"center",width:"100px",minWidth:"100px"}));export{i as g};
